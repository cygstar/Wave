BASS_AC3 2.4

� 2002-2012, Sebastian Andersson (sebastian.andersson@gmail.com). All rights reserved.
Portions � 2006 Dolby Laboratories, Inc. All rights reserved.

All trademarks and other registered names contained in the BASS_AC3
package are the property of their respective owners.


What is BASS_AC3?
=================
BASS_AC3 is an extension to the BASS audio library that enables the playback
of Dolby Digital AC-3 streams.


What is AC-3?
=============
Please visit:

http://www.dolby.com/professional/pro_audio_engineering/solutions_digitaltv.html


Disclaimer
==========
BASS_AC3 is provided "as is" and without warranties of any kind, either express
or implied. The author assumes no liability for damages, direct or consequential,
which may result from the use of BASS_AC3.


Costs
=====
The BASS_AC3 library is free to use and distribute as long as you follow the guidelines
of the GPL.

If you enjoy BASS_AC3, please consider donating money. You may use PayPal to make a donation:

https://www.paypal.com/cgi-bin/webscr?cmd=_xclick&business=sebastian%2eandersson%40gmail%2ecom&item_name=BASS%20Add%2dOns&item_number=1&no_shipping=1&no_note=1&tax=0&currency_code=EUR